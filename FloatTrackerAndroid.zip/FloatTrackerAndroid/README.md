# Float Tracker (Android prototype)

This is a first Android Studio prototype for watching a fishing float with the rear camera.

## What it currently does
- Shows a live CameraX preview.
- Analyses camera frames for bright red/orange/yellow pixels.
- Marks the colour centroid with a green tracking reticle.
- Reports a possible bite after sudden movement or a period where a previously detected float disappears.
- Provides a sensitivity slider and sound/vibration alerts.

## Important limitations
This is a colour-based prototype, not a finished fishing-grade detector or a trained AI model. It may confuse the float with bright tackle, clothing, reflections, buoys, leaves or other objects. Waves, changing light, autofocus and phone movement can cause false alerts. Test it in a safe, controlled setting before relying on it. Keep the phone secured and do not leave it where it could fall into water.

The initial detector groups all qualifying bright pixels together. A next development step should add connected-component filtering, a user-selected region/colour calibration, temporal filtering, horizon/water masking and a more robust object tracker. A useful bite classifier should distinguish a vertical dip from normal lateral drift and waves.

## Build
1. Install Android Studio (current stable version).
2. Open this folder as an existing project.
3. Allow Gradle to sync and install the Android SDK requested by the project (compile SDK 35).
4. Connect an Android phone with USB debugging enabled, or use a supported emulator with a camera.
5. Press Run. Grant camera permission.
6. Point the rear camera at a brightly coloured float. Press **Start tracking**.

Requires JDK 17 and Android Gradle Plugin 8.7.3. Gradle may need an internet connection the first time to download dependencies.

## Suggested next improvements
- Tap-to-calibrate the exact float colour and region.
- Separate individual colour blobs and choose the most plausible float candidate.
- Add a selectable float colour (red, orange, yellow, chartreuse).
- Add a stable baseline and a vertical-submersion detector.
- Add an always-on/foreground tracking mode with battery and thermal safeguards.
- Save bite events with timestamps and optional short clips.
