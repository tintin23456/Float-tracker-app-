package com.example.floattracker

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Canvas
import android.graphics.RectF
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var marker: TrackingOverlay
    private lateinit var status: TextView
    private lateinit var detail: TextView
    private lateinit var sensitivity: SeekBar
    private lateinit var cameraExecutor: ExecutorService
    private var tracking = false
    private var lastX: Float? = null
    private var lastY: Float? = null
    private var lastSeenAt = 0L
    private var lastAlertAt = 0L
    private var stableFrames = 0
    private var tone: ToneGenerator? = null

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else status.text = "Camera permission is needed to track your float."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        tone = ToneGenerator(AudioManager.STREAM_ALARM, 80)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 24, 32))
            setPadding(16, 12, 16, 12)
        }
        val heading = TextView(this).apply {
            text = "FLOAT TRACKER"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        root.addView(heading)

        val cameraFrame = android.widget.FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        marker = TrackingOverlay(this)
        cameraFrame.addView(previewView)
        cameraFrame.addView(marker)
        root.addView(cameraFrame, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        status = TextView(this).apply {
            text = "Starting camera…"
            textSize = 19f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 4)
        }
        detail = TextView(this).apply {
            text = "Point the camera at a brightly coloured float."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 2, 0, 8)
        }
        root.addView(status)
        root.addView(detail)

        val sensitivityLabel = TextView(this).apply {
            text = "Bite sensitivity (higher = more sensitive)"
            setTextColor(Color.WHITE)
            textSize = 13f
        }
        root.addView(sensitivityLabel)
        sensitivity = SeekBar(this).apply {
            max = 100
            progress = 55
        }
        root.addView(sensitivity)

        val startStop = Button(this).apply {
            text = "Start tracking"
            setOnClickListener {
                tracking = !tracking
                text = if (tracking) "Stop tracking" else "Start tracking"
                if (tracking) {
                    lastX = null; lastY = null; stableFrames = 0
                    status.text = "Looking for your float…"
                } else {
                    marker.clear()
                    status.text = "Tracking paused"
                }
            }
        }
        root.addView(startStop)
        val note = TextView(this).apply {
            text = "First prototype: detects bright red/orange/yellow colours. Keep the float visible and the phone steady."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 2)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image ->
                try { analyseFrame(image) } finally { image.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                status.text = "Camera ready"
            } catch (e: Exception) {
                status.text = "Could not start camera: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // Simple colour-based detector. This is a practical first prototype, not a trained AI model.
    private fun analyseFrame(image: ImageProxy) {
        if (!tracking) return
        val plane = image.planes.firstOrNull() ?: return
        val buffer = plane.buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val w = image.width
        val h = image.height
        var count = 0
        var sumX = 0.0
        var sumY = 0.0
        var minX = w
        var minY = h
        var maxX = 0
        var maxY = 0

        // Sample every 3 pixels to keep analysis light on the phone.
        for (y in 0 until h step 3) {
            for (x in 0 until w step 3) {
                val i = y * rowStride + x * pixelStride
                if (i + 2 >= data.size) continue
                val r = data[i].toInt() and 0xff
                val g = data[i + 1].toInt() and 0xff
                val b = data[i + 2].toInt() and 0xff
                val orangeRed = r > 155 && g > 45 && r > g * 1.18 && r > b * 1.35 && b < 145
                val yellow = r > 190 && g > 145 && b < 105
                if (orangeRed || yellow) {
                    count++
                    sumX += x
                    sumY += y
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        val enoughPixels = count >= 8
        if (enoughPixels) {
            val cx = (sumX / count / w).toFloat()
            val cy = (sumY / count / h).toFloat()
            val now = SystemClock.elapsedRealtime()
            val previousX = lastX
            val previousY = lastY
            val movement = if (previousX != null && previousY != null)
                kotlin.math.sqrt((cx - previousX) * (cx - previousX) +
                    (cy - previousY) * (cy - previousY)) else 0f
            lastX = cx
            lastY = cy
            lastSeenAt = now
            stableFrames++

            // Account for camera rotation when placing the marker over the preview.
            val point = rotatePoint(cx, cy, image.imageInfo.rotationDegrees)
            runOnUiThread {
                marker.setPoint(point.first, point.second)
                status.text = if (stableFrames < 5) "Float found — locking on…" else "FLOAT TRACKED"
                detail.text = "Colour pixels: $count   Movement: ${"%.3f".format(movement)}"
            }

            val threshold = 0.012f + (100 - sensitivity.progress) * 0.00035f
            if (stableFrames > 5 && movement > threshold) {
                maybeAlert("Possible bite: sudden float movement")
            }
        } else {
            val now = SystemClock.elapsedRealtime()
            if (lastSeenAt > 0 && now - lastSeenAt > 900) {
                runOnUiThread {
                    marker.clear()
                    status.text = "FLOAT NOT VISIBLE"
                    detail.text = "The float may be submerged, hidden by a wave, or out of frame."
                }
                if (stableFrames > 5) maybeAlert("Possible bite: float disappeared")
                stableFrames = 0
            } else if (lastSeenAt == 0L) {
                runOnUiThread {
                    status.text = "Looking for your float…"
                    detail.text = "Try to keep the coloured tip in view."
                }
            }
        }
    }

    private fun rotatePoint(x: Float, y: Float, degrees: Int): Pair<Float, Float> {
        return when (degrees) {
            90 -> Pair(1f - y, x)
            180 -> Pair(1f - x, 1f - y)
            270 -> Pair(y, 1f - x)
            else -> Pair(x, y)
        }
    }

    private fun maybeAlert(message: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastAlertAt < 5000) return
        lastAlertAt = now
        runOnUiThread {
            status.text = message
            detail.text = "Check your float — this may also be a wave or camera movement."
            try { tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700) } catch (_: Exception) {}
            try {
                val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                    getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                } else null
                val v = vibrator?.defaultVibrator
                    ?: (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                if (android.os.Build.VERSION.SDK_INT >= 26)
                    v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") v.vibrate(350)
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        tone?.release()
        tone = null
    }
}

private class TrackingOverlay(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private var xNorm: Float? = null
    private var yNorm: Float? = null

    fun setPoint(x: Float, y: Float) {
        xNorm = x.coerceIn(0f, 1f)
        yNorm = y.coerceIn(0f, 1f)
        postInvalidate()
    }

    fun clear() {
        xNorm = null
        yNorm = null
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val x = xNorm ?: return
        val y = yNorm ?: return
        val cx = x * width
        val cy = y * height
        canvas.drawCircle(cx, cy, 28f, paint)
        canvas.drawLine(cx - 40, cy, cx + 40, cy, paint)
        canvas.drawLine(cx, cy - 40, cx, cy + 40, paint)
    }
}
